// Desirae Prather
//  memmgr.c
//  memmgr
//
//  Created by William McCarthy on 17/11/20.
//  Copyright © 2020 William McCarthy. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdbool.h>
#define ARGC_ERROR 1
#define FILE_ERROR 2
#define BUFLEN 256
#define FRAME_SIZE  256
#define PAGE_TABLE_SIZE 256
#define TLB_SIZE 16
#define FRAME 128
#define REPLACE FIFO
#define LRU 1
#define FIFO 0
FILE *fbinStore;
//-------------------------------------------------------------------
unsigned getpage(unsigned x) { return (0xff00 & x) >> 8; }

unsigned getoffset(unsigned x) { return (0xff & x); }

void getpage_offset(unsigned x) {
  unsigned  page   = getpage(x);
  unsigned  offset = getoffset(x);
  printf("x is: %u, page: %u, offset: %u, address: %u, paddress: %u\n", x, page, offset,
         (page << 8) | getoffset(x), page * 256 + offset);
}
unsigned int getPgTableUsed(bool*pt[][PAGE_TABLE_SIZE]){
  for (int i=0;i<PAGE_TABLE_SIZE;i++){
    if(!pt[2][i]&&pt[1][i]){
      return (unsigned int)i;
    }
  }
   for (int i=0;i<PAGE_TABLE_SIZE;i++){
    pt[2][i]=false;//used
  }
  for (int i=0;i<PAGE_TABLE_SIZE;i++){
    if(!pt[2][i]&&pt[1][i]){
      return (unsigned int)i;
    }
  }
  return (unsigned int)-1;

}
void UpdateFrame(int* pt[][PAGE_TABLE_SIZE],bool* ptState[][PAGE_TABLE_SIZE],unsigned int pnum, unsigned int Fnum){
  pt[2][pnum]=Fnum;//frame
  ptState[1][pnum]=true;//present
  ptState[2][pnum]=true;//used
}
int findFrame(int* pt[][PAGE_TABLE_SIZE],bool* ptState[][PAGE_TABLE_SIZE], unsigned int f){
  for (int i = 0; i< PAGE_TABLE_SIZE;i++){
    if(pt[2][i]==f&&ptState[1][i]==true){
      return i;
    }
  }
  return -1;
}

int CheckTLB(int* tlb[][TLB_SIZE],unsigned int p){
    for (int i=0;i<TLB_SIZE;i++){
      if (tlb[1][i]==p){
        return i;
      }
    }
   return -1;
}
void addTLB(int* tlb[][TLB_SIZE],int idx,int e){
  tlb[3][idx]=e;//entry
}
void removeTLB(int* tlb[][TLB_SIZE],bool* tlbstate[][TLB_SIZE], int idx){
  tlb[1][idx]=(unsigned int)-1;
  tlbstate[1][idx]=false;
}

int main(int argc, const char* argv[]) {
  FILE* fadd = fopen("addresses.txt", "r");    // open file addresses.txt  (contains the logical addresses)
  if (fadd == NULL) { fprintf(stderr, "Could not open file: 'addresses.txt'\n");  exit(FILE_ERROR);  }

  FILE* fcorr = fopen("correct.txt", "r");     // contains the logical and physical address, and its value
  if (fcorr == NULL) { fprintf(stderr, "Could not open file: 'correct.txt'\n");  exit(FILE_ERROR);  }
  
  
  // opens "BACKING_STORE.bin"
  fbinStore= fopen("BACKING_STORE.bin","rb");
    if (fbinStore==NULL){
    fprintf(stderr, "Could not open file: 'BACKING_STORE.bin'\n"); 
    exit(FILE_ERROR);
  }


  char buf[BUFLEN];
  unsigned   page, offset, physical_add, frame = 0,v=0;
  unsigned   logic_add;                  // read from file address.txt
  unsigned   virt_add, phys_add, value;  // read from file correct.txt
  int used =0,fault =0,tlb_hit=0;
  bool full = false;
  char* fptr=(char*)malloc(FRAME_SIZE*FRAME);


  printf("ONLY READ FIRST 20 entries -- TODO: change to read all entries\n\n");

  // not quite correct -- should search page table before creating a new entry
      //   e.g., address # 25 from addresses.txt will fail the assertion
      // TODO:  add page table code
      int PageTable[2][PAGE_TABLE_SIZE];
      bool pageTablePState[2][PAGE_TABLE_SIZE];

      for (int i = 0; i < PAGE_TABLE_SIZE; i++){
        PageTable[1][i]=(unsigned int)i;//page
        pageTablePState[1][i]=false;// keeps track of present
        pageTablePState[2][i]=false;// keeps track of used

      }

      // TODO:  add TLB code
      int TLB[3][TLB_SIZE];
      bool TLBState[2][TLB_SIZE];
     for (int i = 0; i < TLB_SIZE; i++){
        TLB[1][i]=(unsigned int)-1;//page
        TLBState[1][i]=false;// keeps track of present
        TLBState[2][i]=false;// keeps track of used
      }
      int tlbIndex=0;

 // while (frame < 20) {
   for(int i=0;i<1000;++i){

    fscanf(fcorr, "%s %s %d %s %s %d %s %d", buf, buf, &virt_add,
           buf, buf, &phys_add, buf, &value);  // read from file correct.txt

    fscanf(fadd, "%d", &logic_add);  // read from file address.txt
    page   = getpage(  logic_add);
    offset = getoffset(logic_add);
    
    physical_add = frame++ * FRAME_SIZE + offset;
    
    assert(physical_add == phys_add);
    
    int r = CheckTLB(TLB,page);
    //checking TLB
    if(r>=0){
      ++tlb_hit;
      frame=TLB[2][r];//frame
      page=TLB[1][r];//page
      pageTablePState[2][r]=true;//used
    }
    else if (pageTablePState[1][r]){
      frame=PageTable[2][r];
      pageTablePState[2][r]=true;//used
      addTLB(TLB,tlbIndex,PageTable[page]);
      tlbIndex%=TLB_SIZE;
    }
    else{
      ++fault;
      if (used>=FRAME){
        //FIFO
        if(REPLACE== FIFO){used=0;}
        full=true;

      }
      frame=used;
      if(full){
        if(REPLACE==FIFO){
          int p=findFrame(*PageTable,pageTablePState,frame);
          if(p!=-1){pageTablePState[1][p]=false;}
          int entry= CheckTLB(TLB,(unsigned int) p);
          if(entry!=-1){removeTLB(TLB,TLBState,entry);}

        }
      else{
        //LRU
        unsigned int p=getPgTableUsed(pageTablePState);//find unused page recently

        frame=PageTable[2][p];
        pageTablePState[1][p]=false;//present
        int e = CheckTLB(TLB,(unsigned int)p);
        if(e != -1){
          removeTLB(TLB,TLBState,e);}
          }
    }
    fseek(fbinStore, page * FRAME_SIZE,SEEK_SET);
    fread(buf,FRAME_SIZE,1,fbinStore);
    for (int i =0; i<FRAME_SIZE; i++){
      *(fptr+(frame*FRAME_SIZE)+i)=buf[i];
    }
    UpdateFrame(PageTable,pageTablePState,page,frame);
    addTLB(TLB,tlbIndex++,PageTable[1][page]);
    tlbIndex%=TLB_SIZE;
    ++used;
    }
    physical_add = (frame * FRAME_SIZE) + offset;
    v = *(fptr + physical_add);
    assert(v==value);
// todo: read BINARY_STORE and confirm value matches read value from correct.txt
    printf("logical: %5u (page: %3u, offset: %3u) ---> physical: %5u -- passed\n", logic_add, page, offset, physical_add,(unsigned int)v);
    if (frame % 5 == 0) { printf("\n"); }
  }
  printf("\nPage Fault: %1.3f%%", (double)fault / 1000);
  printf("\nTLB Hit: %1.3f%%\n\n", (double)tlb_hit / 1000);
  printf("ALL logical ---> physical assertions PASSED!\n");
  printf("\n\t\t...done.\n");
  fclose(fcorr);
  fclose(fadd);
  fclose(fbinStore);
  
  printf("ONLY READ FIRST 20 entries -- TODO: change to read all entries\n\n");
  
  printf("ALL logical ---> physical assertions PASSED!\n");
  printf("!!! This doesn't work passed entry 24 in correct.txt, because of a duplicate page table entry\n");
  printf("--- you have to implement the PTE and TLB part of this code\n");

//  printf("NOT CORRECT -- ONLY READ FIRST 20 ENTRIES... TODO: MAKE IT READ ALL ENTRIES\n");

  printf("\n\t\t...done.\n");
  return 0;
}
